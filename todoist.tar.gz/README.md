# recipe-todoist
Recipe for Todoist integration with Franz 5

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
