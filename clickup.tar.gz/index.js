// just pass through Franz
module.exports = Franz => class Clickup extends Franz {
};
