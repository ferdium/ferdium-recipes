# franz-thelounge
A recipe to add "The Lounge - Self-hosted web IRC client" to Franz.
