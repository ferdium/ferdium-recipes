# Monica HQ for Franz
This is an inofficial Franz recipe for [Monica HQ](https://www.monicahq.com/).

# Asset License
* The Monica HQ logo is licensed under [AGPL 3](https://github.com/monicahq/monica/blob/master/LICENSE).

## How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)