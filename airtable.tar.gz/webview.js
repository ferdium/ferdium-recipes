{
  "id": "airtable",
  "name": "Airtable",
  "version": "1.0.1",
  "description": "Airtable",
  "main": "index.js",
  "author": "Casey Sparks <caseyalexsparks@gmail.com>",
  "license": "MIT",
  "repository": "https://github.com/transnat/recipe-airtable",
  "config": {
    "serviceURL": "https://airtable.com",
    "hasTeamId": false,
    "hasCustomUrl": false,
    "hasNotificationSound": false,
    "hasIndirectMessages": false
  }
}
