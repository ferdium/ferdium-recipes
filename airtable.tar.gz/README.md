# recipe-franz-airtable
This is a recipe that adds Airtable to Franz 5.0. The recipe is not yet an implemented service of Franz.

## How to install
You can install it manually by following the instructions below.

1. Download this recipe: https://github.com/transnat/recipe-airtable/archive/master.zip
2. Open the Franz Plugins folder on your machine:
  * Mac: `~/Library/Application Support/Franz/recipes/dev/`
  * Windows: `%appdata%/Franz/recipes/dev/`
3. Create the `dev` folder if you don't yet have it.
4. Unzip the file you have just downloaded.
5. Copy the `recipe-airtable-master` folder into the plugins dev directory
6. Reload Franz
7. Open Franz settings. Under 'Add New Services' you will find a 'Custom Services' section, click on 'Airtable' and log in.
