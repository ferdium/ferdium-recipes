# Microsoft Kaizala
This is the official Franz recipe for Microsoft Kaizala

### How to create your own Franz recipes:
* [Read the documentation](https://meetfranz.com/developer)
