// just pass through Franz
// todo allow custom url
module.exports = Franz => class HackMd extends Franz {
};
