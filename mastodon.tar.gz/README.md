# franz-plugin-mastodon

[franz](http://meetfranz.com/) integration for [Mastodon](https://github.com/tootsuite/mastodon).

see http://qiita.com/kan/items/571b2f56c54e1e3b6516
