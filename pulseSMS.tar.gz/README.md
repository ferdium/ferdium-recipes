# Pulse SMS for Franz
This is the Franz 5 Recipe for Pulse SMS

### For further informtion on Pulse SMS:
* [Visit the website](https://messenger.klinkerapps.com/overview/)

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
