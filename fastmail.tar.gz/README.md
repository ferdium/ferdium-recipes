# Franz-FastMail

This is a service recipe for the [Franz](https://meetfranz.com/) cross-platform messenger to add support for [FastMail](https://www.fastmail.com).

This version of the recipe for Franz 5.

For a version compatible with Franz 4 (legacy) see the [franz4 branch](https://github.com/foss-haas/franz-fastmail/tree/franz4).

## License

The MIT license.

