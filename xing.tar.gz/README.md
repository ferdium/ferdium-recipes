# XING Messenger integration for Franz

See https://github.com/meetfranz/plugins/tree/master/docs for more information on Franz plugin development

# License
MIT

