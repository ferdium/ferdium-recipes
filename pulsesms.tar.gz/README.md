# PulseSMS for Franz
This is a Franz recipe for PulseSMS web client

[Pulsesms.app](https://pulsesms.app)

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
