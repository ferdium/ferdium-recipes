# franz-roundcube
A recipe to add Roundcube support to Franz.