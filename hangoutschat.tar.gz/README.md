# Hangouts Chat for Franz
This is the official Franz recipe for Hangouts Chat

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
