# StandardNotes for Franz
This repository hosts the [StandardNotes](https://standardnotes.org/) Recipe for [Franz](https://meetfranz.com/).