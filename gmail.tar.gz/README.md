# Gmail for Franz
This is the official Franz recipe for Gmail

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
