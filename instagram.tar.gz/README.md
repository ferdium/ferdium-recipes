# Franz Instagram recipe

A Franz recipe for Instagram service.
