# Inbox by Gmail for Franz
This is the official Franz recipe for Inbox by Gmail

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
