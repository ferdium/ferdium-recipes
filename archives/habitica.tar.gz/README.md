# Habitica for Franz
This is the Franz recipe for [Habitica](https://habitica.com)

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
