module.exports = Franz => Franz
