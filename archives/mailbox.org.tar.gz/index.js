// default integration (e.g messenger.com, ...)
module.exports = Franz => Franz;