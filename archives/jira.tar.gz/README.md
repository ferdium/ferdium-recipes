# Jira for Franz
This is the unofficial Franz recipe for Jira

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
