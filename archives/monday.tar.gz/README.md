# Monday for Franz
Unofficial support for monday.com in Franz

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
