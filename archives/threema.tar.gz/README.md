# Threema for Franz
This is a non-official Franz recipe for Threema

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
