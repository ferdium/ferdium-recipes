# Noisli for Ferdi

An unofficial Ferdi recipe for Noisli.

