# Asana for Franz
Asana recipe for Franz 5 !

# Installation
1. Open the Franz Plugins folder on your machine (note that this dev directory may not exist yet, and you must create it):
  - Mac: ~/Library/Application Support/Franz/recipes/dev/
  - Windows: %appdata%/Franz/recipes/dev/
  - Linux: ~/.config/Franz/recipes/dev
2. Copy the franz-recipe-asana folder into the plugins directory
3. Reload Franz
