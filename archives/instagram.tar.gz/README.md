# Instagram for Ferdi
This is the official Ferdi recipe for Instagram

### How to create your own Ferdi recipes:
* [Read the documentation](https://github.com/getferdi/recipes/blob/master/docs/integration.md)