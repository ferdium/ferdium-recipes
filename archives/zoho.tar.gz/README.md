# Zoho Mail for Franz 5
from plugins legacy 
[meetfranz](https://github.com/meetfranz/franz)

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
