# Zeplin Franz Plugin

Follow instructions [here](https://github.com/meetfranz/plugins/blob/master/docs/integration.md) for installation of this plugin.
