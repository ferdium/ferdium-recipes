# Franz 5 Recipe: Workplace by facebook
This recipe integrates the Workplace Chat by facebook into Franz.

You can get the latest version of Franz [here](https://meetfranz.com/).