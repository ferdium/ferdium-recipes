# Guilded for Ferdi
This is the unofficial Ferdi recipe for Guilded, it only supports the current server.

### Release notes
1.0.0: First version

### How to create your own Ferdi recipes:
* [Read the documentation](https://github.com/getferdi/recipes/blob/master/docs/integration.md)