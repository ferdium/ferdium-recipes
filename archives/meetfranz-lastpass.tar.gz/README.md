# meetfranz-lastpass
This recipe allows you to use your lastpass vault in Franz.

# How do I install this recipe?
To install this new integration create the follow directory:
Mac: ~/Library/Application Support/Franz/recipes/dev/meetfranz-lastpass
Windows: %appdata%/Franz/recipes/dev/meetfranz-lastpass
Linux: ~/.config/Franz/recipes/dev/meetfranz-lastpass

Clone the repo in the /recipes/ directory (not in dev).

That's all.

# Check my-new.me

# Notice
Unfortunately, on windows can't see the caret. :(