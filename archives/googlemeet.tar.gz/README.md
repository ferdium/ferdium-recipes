# information
Google Meet Recipe for @getferdi 🥳 Download Ferdi at https://getferdi.com/

# how to import these recipes to your ferdi
1. Clone this repo to your computer
2. Rename this repo to a simple name like "gmeet"
3. Copy your renamed folder to the following locations (if there are not available you must create it)
* Mac: ~/Library/Application Support/Ferdi/recipes/dev/
* Windows: %appdata%/Ferdi/recipes/dev/
* Linux: ~/.config/Ferdi/recipes/dev
4. Reload Ferdi
5. Navigate to your "add service" section in Ferdi and added to yours.
