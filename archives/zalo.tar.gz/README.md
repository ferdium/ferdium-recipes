# Zalo for Ferdi
This is a Ferdi recipe for Zalo

### How to create your own Ferdi recipes:
* [Read the documentation](https://github.com/getferdi/recipes/blob/master/docs/integration.md)
