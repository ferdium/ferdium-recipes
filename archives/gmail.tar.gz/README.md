# Gmail for Franz/Ferdi
This is an edited version of the official Franz recipe for Gmail

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
