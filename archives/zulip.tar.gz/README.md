# Zulip for Franz
This is the Franz 5 Recipe for Zulip

### For further informtion on Zulip:
* [Visit the website](https://zulipchat.com/why-zulip/)

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)