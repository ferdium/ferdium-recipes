# Clubhouse for Franz
This is a community Ferdi recipe for [Clubhouse](https://clubhouse.io)
