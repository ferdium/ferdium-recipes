# Wunderlist for RainLoop
This is a Franz recipe for RainLoop, it was migrated by [Marcel Deglau](https://github.com/promarcel) and comes originally from [ffflorian](https://github.com/ffflorian).

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)