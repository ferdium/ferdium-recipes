# The Epic Game Store for Ferdi

An unofficial Ferdi recipe for the Epic Games Store

*NOTE: Technically, the service URL is should be `https://www.epicgames.com/store/en-US/` but it has been set to the login page so that the login prompt is shown, followed by a redirect*
