# Gotomeeting for Ferdi
This is my personnal Ferdi recipe for Gotomeeting

