# Office 365 Outlook Web App for Franz
This is the Franz 5 Recipe for Office 365 Outlook Web App

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
