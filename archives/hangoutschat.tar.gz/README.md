# Hangouts Chat for Franz

This is a clone of the [official Franz recipe for Hangouts Chat](https://github.com/meetfranz/recipe-hangoutschat) to 
merge the pending PRs, specially the one that fixes the notifications badge.

## Installation 

You need to apply the plugin manually.

1. Create the directory `~/.config/Franz/recipes/dev/recipe-hangoutschat`
2. Copy the files from this repository into the new folder
3. Reload Franz
4. Add "Hangouts Chat (Non official)" in Add Service > Custom Service > Hangouts Chat (Non official)
5. Close Franz, start it again and add your account again.
