# Google Drive for Franz

Google Drive Recipe for [Franz](http://meetfranz.com), fixed for files not being displayed.

### Installation

1. Download/clone this repo to your computer

2. Copy the recipe folder to the following location (you may need to create the `dev` folder):
* Mac: `~/Library/Application Support/Franz/recipes/dev/`
* Windows: `%appdata%/Franz/recipes/dev/`
* Linux: `~/.config/Franz/recipes/dev`

3. Relaod Franz

4. Navigate to "Add Service -> Development" section in Franz.