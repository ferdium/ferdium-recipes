# franz-recipe-netatmo-energy

This is a recipe for [Franz](meetfranz.com) that provides access to the Energy dashboard for [Netatmo](netatmo.com) products.
