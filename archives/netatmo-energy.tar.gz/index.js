"use strict";

// just pass through Franz
module.exports = function (Franz) {
  return Franz;
};