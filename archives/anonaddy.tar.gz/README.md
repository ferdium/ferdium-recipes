# AnonAddy for Ferdi

An unofficial Ferdi recipe for AnonAddy 
