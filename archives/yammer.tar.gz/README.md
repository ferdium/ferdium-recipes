# Franz Recipe for Yammer

This is the unofficial [Franz 5](https://meetfranz.com/) recipe for [Yammer](https://www.yammer.com/).
