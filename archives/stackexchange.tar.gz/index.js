module.exports = Ferdi => class stackexchange extends Ferdi {
};
