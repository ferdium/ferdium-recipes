# Riseup.net for Ferdi

This is a Ferdi recipe for Riseup.net webmail.

[Built using the Ferdi recipe creation script](https://github.com/getferdi/recipes/blob/master/docs/integration.md).

[Riseup.net logo](https://riseup.net/en/about-us/images) used under [CC BY-NC-SA](https://creativecommons.org/licenses/by-nc-sa/3.0/) / Modified from original
