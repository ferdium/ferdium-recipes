module.exports = Ferdi => class riseupnet extends Ferdi {
};
