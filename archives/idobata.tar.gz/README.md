# Idobata for Franz

---

This is the Franz 5 Recipe for Idobata.

## For furher information on Idobata:

[Idobata](https://idobata.io/en/home) is a chat service.

## Installation for Development

copy files to [Franz Plugins folder](http://github.com/meetfranz/plugins/blob/master/docs/integration.md#installation).

## License

This plugins are available as open source under the terms of the [MIT License](http://opensource.org/licenses/MIT).
