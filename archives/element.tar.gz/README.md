# Element for Franz
This is a Franz recipe/plugin for Element
