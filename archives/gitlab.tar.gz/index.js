module.exports = Ferdi => class gitlab extends Ferdi {
};
