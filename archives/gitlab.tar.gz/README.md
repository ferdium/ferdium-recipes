# GitLab for Ferdi

An unofficial Ferdi recipe for GitLab CI

*NOTE: Technically, the service URL is should be `https://gitlab.com/` but it has been set to the login page because the service URL on account without logins redirect to `https://about.gitlab.com/`*
