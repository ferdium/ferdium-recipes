"use strict";
module.exports = Franz => Franz;