# Riot for Franz
This is a Franz recipe/plugin for Riot 5

## Installation
1. Download or clone this repo on your computer
2. Open the Franz Plugins folder on your machine:
  * Mac: `~/Library/Application Support/Franz/recipes/dev/`
  * Windows: `%appdata%/Franz/recipes/dev/`
3. Copy the `recipe-riot` folder into the `dev` directory (if the directory does not exist, create it)
4. Reload Franz
5. Open `Settings` tab and enable Riot in the `development` tab of `Available services`
