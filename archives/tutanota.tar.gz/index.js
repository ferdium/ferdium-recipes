module.exports = Ferdi => class tutanota extends Ferdi {
};
