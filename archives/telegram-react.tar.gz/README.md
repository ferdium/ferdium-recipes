# Telegram for Ferdi

This is the official Ferdi recipe for Telegram

### How to create your own Franz recipes:

- [Read the documentation](https://github.com/getferdi/recipes/tree/master/docs)
