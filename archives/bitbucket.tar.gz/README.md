# BitBucket for Ferdi

An unofficial Ferdi recipe for Atlassian's BitBucket 
