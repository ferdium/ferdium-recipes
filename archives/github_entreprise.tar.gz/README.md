# GitHub Enterprise Franz Plugin

Follow instructions [here](https://github.com/meetfranz/plugins/blob/master/docs/integration.md) for installation of this plugin.

Inspired by _GitHub Franz Plugin_: https://github.com/redsox2002/recipe-franz-github
