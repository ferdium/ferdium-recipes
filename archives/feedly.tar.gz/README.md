# Ferdi 5 Recipe: Feedly
This recipe integrates Feedly into Ferdi.
