# Steam Chat for Franz
An unofficial Franz recipe for Steam Chat

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
