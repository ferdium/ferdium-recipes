# Cisco Spark for Franz
This is the official Franz recipe for Cisco Spark

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
