# Pomodoro Tracker for Ferdi
This is a Ferdi recipe for Pomodoro Tracker, a productivity app designed for your work and study. 
Pomodoro Tracker is an app created by Kirill Klenov <horneds@gmail.com>.

Pomodoro Tracker icon comes from FontAwesome icon set (check-circle) and is used under Creative Commons Attribuiton 4.0. <https://fontawesome.com/license>
