# recipe-franz-zenhub
Franz recipe for Zenhub service
