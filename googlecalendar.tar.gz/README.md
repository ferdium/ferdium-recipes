# Franz 5 Recipe: Google Calendar
This recipe integrates the Google Calendar into Franz.

You can get the latest version of Franz [here](https://meetfranz.com/).