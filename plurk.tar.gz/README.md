## Plurk Franz Recipe

### Service Website
https://www.plurk.com

### Notification Period
10 seconds

### Notification Count
- New Posts(新訊息) + Reply(未讀訊息)
- now they are counted as direct messages (Plurk users may read all unread messages.)

### About making a recipe of Franz
[Read this](https://github.com/meetfranz/plugins/tree/master/docs)

### Todo
