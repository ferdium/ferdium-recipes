// just pass through Franz
module.exports = Franz => Franz;