# MySMS for Franz
This is the official Franz recipe for MySMS

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
