# Zimbra for Ferdi
This is the official Ferdi recipe for Zimbra

### How to create your own Ferdi recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
