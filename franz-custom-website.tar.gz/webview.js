"use strict";

module.exports = () => {};